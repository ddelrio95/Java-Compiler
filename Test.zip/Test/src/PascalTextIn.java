/**
 * <h1>PascalTextIn</h1>
 *
 * <p>Pascal Runtime Library:
 * Runtime text input for Pascal programs.</p>
 *
 * <p>Copyright (c) 2009 by Ronald Mak</p>
 * <p>For instructional purposes only.  No warranties.</p>
 */
public class PascalTextIn
{
}
