package wci.intermediate;

/**
 * <h1>TypeKey</h1>
 *
 * <p>The interface for a type specification attribute key.</p>
 *
 * <p>Copyright (c) 2009 by Ronald Mak</p>
 * <p>For instructional purposes only.  No warranties.</p>
 */
public interface TypeKey
{
}
